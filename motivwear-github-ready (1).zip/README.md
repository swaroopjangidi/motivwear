# 👕 MotivWear — Anime T-Shirt Store

**MotivWear** is a modern anime-inspired motivational T-shirt store built using **React + TailwindCSS**.  
Every design celebrates the energy of *Shonen heroes* — “Believe in Your Power!” ⚡

---

## 🌟 Live Demo
Once deployed, your site will be available at:  
👉 https://YOUR-USERNAME.github.io/motivwear/

---

## 🧩 Features
- ⚡ Full single-page design with React (no backend needed)
- 🧥 Stylish Anime/Shonen T-shirt catalog
- 🛒 Functional Cart UI with Add/Remove system
- 🔒 Anti-screenshot & blur protection
- 💳 Ready for Razorpay / Stripe integration
- 📱 Fully responsive (mobile, tablet & desktop)

---

## 🚀 How to Run Locally
```bash
git clone https://github.com/YOUR-USERNAME/motivwear.git
cd motivwear
# Open index.html in browser directly
```

---

## 🧑‍💻 Author
**Bhawani Jangid (Motidesjangid)**  
> "Anime energy meets motivation. Believe in your power!"  
📧 Contact: saroojjangid296@gmail.com

---

## ⚙️ License
MIT License — You can use and modify this project freely for personal or commercial purposes.

---

⭐ **Star this repo** if you like it!
